<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Language" content="zh-cn">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title><?php echo $zbp->Config('system')->ZC_BLOG_NAME; ?> - Sitemap</title>
  <style type="text/css">
    body {
      font-family: Verdana;
      FONT-SIZE: 12px;
      MARGIN: 0;
      color: #000000;
      background: #ffffff;
      padding: 10px 20px 30px 20px;
    }

    img {
      border: 0;
    }

    li {
      margin-top: 8px;
    }

    #nav, .content, #footer {
      padding: 8px;
      border: 1px solid #EEEEEE;
      clear: both;
      width: 95%;
      margin: auto;
      margin-top: 10px;
    }
  </style>
</head>
<body vlink="#333333" link="#333333">
<h1 style="text-align: center; margin-top: 20px">
  <?php echo $zbp->Config('system')->ZC_BLOG_NAME; ?> - Sitemap
</h1>
<div id="nav">
  <a href="<?php echo $zbp->host; ?>">
    <strong><?php echo $zbp->Config('system')->ZC_BLOG_NAME; ?></strong>
  </a>
  &raquo;
  <a href="<?php echo $zbp->host; ?>sitemap/sitemap.html">站点地图</a>
</div>
<div class="60dafe0ae7045 content">
  <table width="100%" border=0 cellspacing=0 cellpadding=0>
