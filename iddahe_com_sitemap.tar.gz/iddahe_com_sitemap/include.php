<?php
RegisterPlugin("iddahe_com_sitemap", "ActivePlugin_iddahe_com_sitemap");

function ActivePlugin_iddahe_com_sitemap()
{
    Add_Filter_Plugin('Filter_Plugin_Index_Begin', 'iddahe_com_sitemap_index_begin');

    // 操作文章更新
    Add_Filter_Plugin('Filter_Plugin_PostArticle_Succeed', 'iddahe_com_sitemap_clear');
    Add_Filter_Plugin('Filter_Plugin_DelArticle_Succeed', 'iddahe_com_sitemap_clear');
    // 操作分类更新
    Add_Filter_Plugin('Filter_Plugin_PostCategory_Succeed', 'iddahe_com_sitemap_clear');
    Add_Filter_Plugin('Filter_Plugin_DelCategory_Succeed', 'iddahe_com_sitemap_clear');
    // 操作标签更新
    Add_Filter_Plugin('Filter_Plugin_PostTag_Succeed', 'iddahe_com_sitemap_clear');
    Add_Filter_Plugin('Filter_Plugin_DelTag_Succeed', 'iddahe_com_sitemap_clear');
    // 操作页面更新
    Add_Filter_Plugin('Filter_Plugin_PostPage_Succeed', 'iddahe_com_sitemap_clear');
    Add_Filter_Plugin('Filter_Plugin_DelPage_Succeed', 'iddahe_com_sitemap_clear');
}

function UninstallPlugin_iddahe_com_sitemap()
{
    // Just so so
}

function InstallPlugin_iddahe_com_sitemap()
{
    // Just so so
}

function iddahe_com_sitemap_index_begin()
{
    global $zbp;

    $xmlStatus = $zbp->Config('iddahe_com_sitemap')->xml_status;
    $txtStatus = $zbp->Config('iddahe_com_sitemap')->txt_status;
    $htmlStatus = $zbp->Config('iddahe_com_sitemap')->html_status;

    $currentUrl = rtrim($zbp->currenturl, '/');

    if (false !== mb_strpos($currentUrl, '?')) {
        $currentUrl = str_replace(
            mb_substr($currentUrl, mb_strpos($currentUrl, '?'), mb_strlen($currentUrl) - mb_strpos($currentUrl, '?')),
            '',
            $currentUrl
        );
    }

    if (false !== mb_strpos($currentUrl, '&')) {
        $currentUrl = str_replace(
            mb_substr($currentUrl, mb_strpos($currentUrl, '&'), mb_strlen($currentUrl) - mb_strpos($currentUrl, '&')),
            '',
            $currentUrl
        );
    }

    if ($xmlStatus && preg_match('/\/sitemap\/sitemap\.xml$/', $currentUrl)) {
        header('Content-Type: text/xml');
        $cache = iddahe_com_sitemap_sitemap_cache_get('xml');
        if (false !== $cache) {
            echo $cache;
            die();
        }
        ob_get_clean();
        ob_start();

        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9/">';
        echo '<url>';
        echo '<loc>' . $zbp->host . '</loc>';
        echo '<lastmod>' . date('Y-m-d') . '</lastmod>';
        echo '<changefreq>daily</changefreq>';
        echo '<priority>1.0</priority>';
        echo '</url>';

        iddahe_com_sitemap_create_sitemap(function ($url, $date, $freq, $level) {
            echo '<url>';
            echo '<loc>' . $url . '</loc>';
            echo '<lastmod>' . $date . '</lastmod>';
            echo '<changefreq>' . $freq . '</changefreq>';
            echo '<priority>' . $level . '</priority>';
            echo '</url>';
        });

        echo '</urlset>';

        iddahe_com_sitemap_sitemap_cache('xml');
        die();
    }

    if ($txtStatus && preg_match('/\/sitemap\/sitemap\.txt$/', $currentUrl)) {
        header('Content-Type: text/plain');
        $cache = iddahe_com_sitemap_sitemap_cache_get('txt');
        if (false !== $cache) {
            echo $cache;
            die();
        }
        ob_get_clean();
        ob_start();

        echo str_replace(array("\n", "\r"), '', trim($zbp->host)) . "\n";

        iddahe_com_sitemap_create_sitemap(function ($url, $date, $freq, $level) {
            echo str_replace(array("\n", "\r"), '', trim($url)) . "\n";
        });

        iddahe_com_sitemap_sitemap_cache('txt');

        die();
    }

    if ($htmlStatus && preg_match('/\/sitemap\/sitemap\.html$/', $currentUrl)) {
        $cache = iddahe_com_sitemap_sitemap_cache_get('html');
        if (false !== $cache) {
            echo $cache;
            die();
        }
        ob_get_clean();
        ob_start();

        include __DIR__ . '/html.header.php';

        $rows = array();
        iddahe_com_sitemap_create_sitemap(function ($url, $date, $freq, $level, $title) use (&$rows) {
            $rows[] = "<td><ul><li><a href=\"{$url}\" target='_blank'>{$title}</a></li></ul></td>\r\n";
            if (count($rows) >= 4) {
                echo "<tr>\r\n";
                foreach ($rows as $row) {
                    echo $row;
                }
                echo "</tr>\r\n";
                $rows = array();
            }
        });

        echo "<tr>\r\n"; // 末尾的
        foreach ($rows as $row) {
            echo $row;
        }
        echo "</tr>\r\n";

        include __DIR__ . '/html.footer.php';

        iddahe_com_sitemap_sitemap_cache('html');

        die();
    }
}

function iddahe_com_sitemap_create_sitemap($callback)
{
    global $zbp;

    $offsetLimit = 500;

    if ($zbp->Config('iddahe_com_sitemap')->post_url_status) {
        $level = $zbp->Config('iddahe_com_sitemap')->post_url_level;
        $frequency = $zbp->Config('iddahe_com_sitemap')->post_url_frequency;

        $postLimit = $zbp->Config('iddahe_com_sitemap')->post_url_number;
        if (0 == $postLimit) {
            $postLimit = 999999999;
        } else {
            $postLimit = $postLimit ? $postLimit : 5000;
        }

        $lastPostId = 0;
        $orderBy = array('log_ID' => 'desc'); // 最新的

        while ($postLimit > 0) {
            $where = array(array('=', 'log_Status', 0));

            if (0 != $lastPostId) {
                $where[] = array('<', 'log_ID', $lastPostId);
            }

            $limit = ($postLimit > $offsetLimit) ? $offsetLimit : $postLimit;
            $articles = $zbp->GetArticleList(null, $where, $orderBy, array($limit));

            if (empty($articles)) {
                break;
            }

            foreach ($articles as $article) {
                $callback($article->Url, date('Y-m-d', $article->PostTime), $frequency, $level, $article->Title);
                $lastPostId = $article->ID;
            }

            $postLimit -= $offsetLimit;
        }
    }

    if ($zbp->Config('iddahe_com_sitemap')->page_url_status) {
        $level = $zbp->Config('iddahe_com_sitemap')->page_url_level;
        $frequency = $zbp->Config('iddahe_com_sitemap')->page_url_frequency;

        $pageLimit = $zbp->Config('iddahe_com_sitemap')->post_url_number;
        if (0 == $pageLimit) {
            $pageLimit = 999999999;
        } else {
            $pageLimit = $pageLimit ? $pageLimit : 5000;
        }

        $lastPostId = 0;
        $orderBy = array('log_ID' => 'desc'); // 最新的

        while ($pageLimit > 0) {
            $where = array(array('=', 'log_Status', 0));

            if (0 != $lastPostId) {
                $where[] = array('<', 'log_ID', $lastPostId);
            }

            $limit = ($pageLimit > $offsetLimit) ? $offsetLimit : $pageLimit;
            $pages = $zbp->GetPageList(null, $where, $orderBy, array($limit));

            if (empty($pages)) {
                break;
            }

            foreach ($pages as $page) {
                $callback($page->Url, date('Y-m-d', $page->PostTime), $frequency, $level, $page->Title);
                $lastPostId = $page->ID;
            }

            $pageLimit -= $offsetLimit;
        }
    }

    if ($zbp->Config('iddahe_com_sitemap')->category_url_status) {
        $level = $zbp->Config('iddahe_com_sitemap')->category_url_level;
        $frequency = $zbp->Config('iddahe_com_sitemap')->category_url_frequency;
        $categoryLimit = $zbp->Config('iddahe_com_sitemap')->category_url_number;
        $categoryLimit = 0 == $categoryLimit ? 999999999 : $categoryLimit;

        $categories = $zbp->GetCategoryList('*', null, null, $categoryLimit);
        foreach ($categories as $category) {
            $callback($category->Url, date('Y-m-d'), $frequency, $level, $category->Name);
        }
    }

    if ($zbp->Config('iddahe_com_sitemap')->tag_url_status) {
        $level = $zbp->Config('iddahe_com_sitemap')->tag_url_level;
        $frequency = $zbp->Config('iddahe_com_sitemap')->tag_url_frequency;

        $tagLimit = $zbp->Config('iddahe_com_sitemap')->tag_url_number;
        if (0 == $tagLimit) {
            $tagLimit = 999999999;
        } else {
            $tagLimit = $tagLimit ? $tagLimit : 5000;
        }

        $lastTagId = 0;
        $orderBy = array('tag_ID' => 'desc'); // 最新的

        while ($tagLimit > 0) {
            $where = array();

            if (0 != $lastTagId) {
                $where = array('<', 'tag_ID', $lastTagId);
            }

            $limit = ($tagLimit > $offsetLimit) ? $offsetLimit : $tagLimit;
            $tags = $zbp->GetTagList(null, $where, $orderBy, array($limit));

            if (empty($tags)) {
                break;
            }

            foreach ($tags as $tag) {
                $callback($tag->Url, date('Y-m-d'), $frequency, $level, $tag->Name);
                $lastTagId = $tag->ID;
            }

            $tagLimit -= $offsetLimit;
        }
    }
}

function iddahe_com_sitemap_sitemap_cache($type)
{
    $dir = __DIR__ . '/cache';

    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    if ('xml' == $type) {
        $xmlFile = "{$dir}/sitemap.xml";
        file_put_contents($xmlFile, ob_get_contents());
    } elseif ('txt' == $type) {
        $txtFile = "{$dir}/sitemap.txt";
        file_put_contents($txtFile, ob_get_contents());
    } elseif ('html' == $type) {
        $htmlFile = "{$dir}/sitemap.html";
        file_put_contents($htmlFile, ob_get_contents());
    }
}

function iddahe_com_sitemap_sitemap_cache_get($type)
{
    $dir = __DIR__ . '/cache';

    if ('xml' == $type) {
        $filename = "{$dir}/sitemap.xml";
    } elseif ('txt' == $type) {
        $filename = "{$dir}/sitemap.txt";
    } elseif ('html' == $type) {
        $filename = "{$dir}/sitemap.html";
    }

    if (is_file($filename)) {
        return file_get_contents($filename);
    }

    return false;
}

function iddahe_com_sitemap_clear()
{
    $files = array(
        __DIR__ . '/cache/sitemap.xml',
        __DIR__ . '/cache/sitemap.txt',
        __DIR__ . '/cache/sitemap.html',
    );

    foreach ($files as $file) {
        if (is_file($file)) {
            @unlink($file);
        }
    }
}
