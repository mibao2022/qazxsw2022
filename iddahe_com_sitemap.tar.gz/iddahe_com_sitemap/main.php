<?php
require_once __DIR__ . '/../../../zb_system/function/c_system_base.php';
require_once __DIR__ . '/../../../zb_system/function/c_system_admin.php';

$zbp->Load();

$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('iddahe_com_sitemap')) {
    $zbp->ShowError(48);
    die();
}
if (count($_POST) > 0) {
    CheckIsRefererValid();
}

$blogtitle = '彦祖专用Sitemap';

$action = isset($_GET['action']) ? $_GET['action'] : null;
$settingClass = ($action == 'setting' || empty($action)) ? 'm-now' : '';

require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';

?>
<div id="divMain">
  <div class="divHeader"><?php echo $blogtitle; ?></div>
  <div class="SubMenu">
    <ul>
      <li>
        <a href="?action=setting">
          <span class="m-left <?php echo $settingClass; ?>">地图设置</span>
        </a>
      </li>
      <li>
        <a href="https://www.iddahe.com/apps/"
           target="_blank">
          <span class="m-left">作者的其他作品 >></span>
        </a>
      </li>
    </ul>
  </div>
  <div id="divMain2">
      <?php include_once __DIR__ . '/module/setting.php'; ?>
  </div>
</div>
<script type="text/javascript">
  AddHeaderIcon("<?php echo $bloghost . 'zb_users/plugin/iddahe_com_sitemap/logo.png';?>");
</script>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>