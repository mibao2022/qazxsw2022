<?php

if (!$zbp->CheckRights('root')) {
    $zbp->ShowError(6);
    die();
}

if (GetVars('sitemap_save')) {
    if (function_exists('CheckIsRefererValid')) {
        CheckIsRefererValid();// 检查 csrfToken
    }

    $zbp->Config('iddahe_com_sitemap')->post_url_status = GetVars('post_url_status');
    $zbp->Config('iddahe_com_sitemap')->post_url_level = GetVars('post_url_level');
    $zbp->Config('iddahe_com_sitemap')->post_url_frequency = GetVars('post_url_frequency');
    $zbp->Config('iddahe_com_sitemap')->post_url_number = GetVars('post_url_number');

    $zbp->Config('iddahe_com_sitemap')->page_url_status = GetVars('page_url_status');
    $zbp->Config('iddahe_com_sitemap')->page_url_level = GetVars('page_url_level');
    $zbp->Config('iddahe_com_sitemap')->page_url_frequency = GetVars('page_url_frequency');
    $zbp->Config('iddahe_com_sitemap')->page_url_number = GetVars('page_url_number');

    $zbp->Config('iddahe_com_sitemap')->category_url_status = GetVars('category_url_status');
    $zbp->Config('iddahe_com_sitemap')->category_url_level = GetVars('category_url_level');
    $zbp->Config('iddahe_com_sitemap')->category_url_frequency = GetVars('category_url_frequency');
    $zbp->Config('iddahe_com_sitemap')->category_url_number = GetVars('category_url_number');

    $zbp->Config('iddahe_com_sitemap')->tag_url_status = GetVars('tag_url_status');
    $zbp->Config('iddahe_com_sitemap')->tag_url_level = GetVars('tag_url_level');
    $zbp->Config('iddahe_com_sitemap')->tag_url_frequency = GetVars('tag_url_frequency');
    $zbp->Config('iddahe_com_sitemap')->tag_url_number = GetVars('tag_url_number');

    $zbp->Config('iddahe_com_sitemap')->xml_status = GetVars('xml_status');
    $zbp->Config('iddahe_com_sitemap')->txt_status = GetVars('txt_status');
    $zbp->Config('iddahe_com_sitemap')->html_status = GetVars('html_status');

    $zbp->SaveConfig('iddahe_com_sitemap');

    iddahe_com_sitemap_clear();

    echo "<script>setTimeout(function(){alert('已保存！');},200);</script>";
}

if (!$zbp->Config('iddahe_com_sitemap')->HasKey('post_url_status')) {
    $zbp->Config('iddahe_com_sitemap')->post_url_status = 1;
    $zbp->Config('iddahe_com_sitemap')->post_url_level = '1.0';
    $zbp->Config('iddahe_com_sitemap')->post_url_frequency = 'daily';
    $zbp->Config('iddahe_com_sitemap')->post_url_number = '5000';

    $zbp->Config('iddahe_com_sitemap')->category_url_status = 1;
    $zbp->Config('iddahe_com_sitemap')->category_url_level = '0.9';
    $zbp->Config('iddahe_com_sitemap')->category_url_frequency = 'hourly';
    $zbp->Config('iddahe_com_sitemap')->category_url_number = '100';

    $zbp->Config('iddahe_com_sitemap')->xml_status = 1;
    $zbp->Config('iddahe_com_sitemap')->txt_status = 1;
    $zbp->Config('iddahe_com_sitemap')->html_status = 1;

    $zbp->SaveConfig('iddahe_com_sitemap');
}

$config = $zbp->Config('iddahe_com_sitemap');

?>
<style>
  form.iddahe_form_table tr:nth-child(n+1) td:first-child {
    text-align: right;
    font-weight: bold
  }
</style>
<form method="post" class="iddahe_form_table">
    <?php
    if (function_exists('CheckIsRefererValid')) {
        echo '<input type="hidden" name="csrfToken" value="' . $zbp->GetCSRFToken() . '">';
    }
    ?>
  <table style="width: 900px">
    <tr>
      <td style="text-align: center"></td>
      <td style="text-align: center">
        配置值，保存配置访问 Sitemap 地址即可，URL 自动更新！！
      </td>
    </tr>
    <tr>
      <td>文章链接</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="post_url_status"
          value="<?php echo $config->post_url_status; ?>">
        &nbsp优先级：
        <select name="post_url_level">
            <?php $postUrlLevel = $config->post_url_level; ?>
          <option value="1.0" <?php echo '1.0' == $postUrlLevel ? 'selected' : ''; ?>>1.0</option>
          <option value="0.9" <?php echo '0.9' == $postUrlLevel ? 'selected' : ''; ?>>0.9</option>
          <option value="0.8" <?php echo '0.8' == $postUrlLevel ? 'selected' : ''; ?>>0.8</option>
          <option value="0.7" <?php echo '0.7' == $postUrlLevel ? 'selected' : ''; ?>>0.7</option>
          <option value="0.6" <?php echo '0.6' == $postUrlLevel ? 'selected' : ''; ?>>0.6</option>
          <option value="0.5" <?php echo '0.5' == $postUrlLevel ? 'selected' : ''; ?>>0.5</option>
          <option value="0.4" <?php echo '0.4' == $postUrlLevel ? 'selected' : ''; ?>>0.4</option>
          <option value="0.3" <?php echo '0.3' == $postUrlLevel ? 'selected' : ''; ?>>0.3</option>
          <option value="0.2" <?php echo '0.2' == $postUrlLevel ? 'selected' : ''; ?>>0.2</option>
          <option value="0.1" <?php echo '0.1' == $postUrlLevel ? 'selected' : ''; ?>>0.1</option>
          <option value="0.0" <?php echo '0.0' == $postUrlLevel ? 'selected' : ''; ?>>0.0</option>
        </select>
        &nbsp&nbsp频率：
        <select name="post_url_frequency">
            <?php $postUrlFrequency = $config->post_url_frequency; ?>
          <option value="always" <?php echo 'always' == $postUrlFrequency ? 'selected' : ''; ?>>always</option>
          <option value="hourly" <?php echo 'hourly' == $postUrlFrequency ? 'selected' : ''; ?>>hourly</option>
          <option value="daily" <?php echo 'daily' == $postUrlFrequency ? 'selected' : ''; ?>>daily</option>
          <option value="weekly" <?php echo 'weekly' == $postUrlFrequency ? 'selected' : ''; ?>>weekly</option>
          <option value="monthly" <?php echo 'monthly' == $postUrlFrequency ? 'selected' : ''; ?>>monthly</option>
          <option value="yearly" <?php echo 'yearly' == $postUrlFrequency ? 'selected' : ''; ?>>yearly</option>
          <option value="never" <?php echo 'never' == $postUrlFrequency ? 'selected' : ''; ?>>never</option>
        </select>
        &nbsp&nbsp数量：
        <input
          type="number"
          min="0"
          name="post_url_number"
          style="width: 80px"
          value="<?php echo $config->post_url_number; ?>">
        (0 表示全部)
      </td>
    </tr>
    <tr>
      <td>页面链接</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="page_url_status"
          value="<?php echo $config->page_url_status; ?>">
        &nbsp优先级：
        <select name="page_url_level">
            <?php $pageUrlLevel = $config->page_url_level; ?>
          <option value="1.0" <?php echo '1.0' == $pageUrlLevel ? 'selected' : ''; ?>>1.0</option>
          <option value="0.9" <?php echo '0.9' == $pageUrlLevel ? 'selected' : ''; ?>>0.9</option>
          <option value="0.8" <?php echo '0.8' == $pageUrlLevel ? 'selected' : ''; ?>>0.8</option>
          <option value="0.7" <?php echo '0.7' == $pageUrlLevel ? 'selected' : ''; ?>>0.7</option>
          <option value="0.6" <?php echo '0.6' == $pageUrlLevel ? 'selected' : ''; ?>>0.6</option>
          <option value="0.5" <?php echo '0.5' == $pageUrlLevel ? 'selected' : ''; ?>>0.5</option>
          <option value="0.4" <?php echo '0.4' == $pageUrlLevel ? 'selected' : ''; ?>>0.4</option>
          <option value="0.3" <?php echo '0.3' == $pageUrlLevel ? 'selected' : ''; ?>>0.3</option>
          <option value="0.2" <?php echo '0.2' == $pageUrlLevel ? 'selected' : ''; ?>>0.2</option>
          <option value="0.1" <?php echo '0.1' == $pageUrlLevel ? 'selected' : ''; ?>>0.1</option>
          <option value="0.0" <?php echo '0.0' == $pageUrlLevel ? 'selected' : ''; ?>>0.0</option>
        </select>
        &nbsp&nbsp频率：
        <select name="page_url_frequency">
            <?php $pageUrlFrequency = $config->page_url_frequency; ?>
          <option value="always" <?php echo 'always' == $pageUrlFrequency ? 'selected' : ''; ?>>always</option>
          <option value="hourly" <?php echo 'hourly' == $pageUrlFrequency ? 'selected' : ''; ?>>hourly</option>
          <option value="daily" <?php echo 'daily' == $pageUrlFrequency ? 'selected' : ''; ?>>daily</option>
          <option value="weekly" <?php echo 'weekly' == $pageUrlFrequency ? 'selected' : ''; ?>>weekly</option>
          <option value="monthly" <?php echo 'monthly' == $pageUrlFrequency ? 'selected' : ''; ?>>monthly</option>
          <option value="yearly" <?php echo 'yearly' == $pageUrlFrequency ? 'selected' : ''; ?>>yearly</option>
          <option value="never" <?php echo 'never' == $pageUrlFrequency ? 'selected' : ''; ?>>never</option>
        </select>
        &nbsp&nbsp数量：
        <input
          type="number"
          min="0"
          name="page_url_number"
          value="<?php echo $config->page_url_number; ?>"
          style="width: 80px">
        (0 表示全部)
      </td>
    </tr>
    <tr>
      <td>分类链接</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="category_url_status"
          value="<?php echo $config->category_url_status; ?>">
        &nbsp优先级：
        <select name="category_url_level">
            <?php $categoryUrlLevel = $config->category_url_level; ?>
          <option value="1.0" <?php echo '1.0' == $categoryUrlLevel ? 'selected' : ''; ?>>1.0</option>
          <option value="0.9" <?php echo '0.9' == $categoryUrlLevel ? 'selected' : ''; ?>>0.9</option>
          <option value="0.8" <?php echo '0.8' == $categoryUrlLevel ? 'selected' : ''; ?>>0.8</option>
          <option value="0.7" <?php echo '0.7' == $categoryUrlLevel ? 'selected' : ''; ?>>0.7</option>
          <option value="0.6" <?php echo '0.6' == $categoryUrlLevel ? 'selected' : ''; ?>>0.6</option>
          <option value="0.5" <?php echo '0.5' == $categoryUrlLevel ? 'selected' : ''; ?>>0.5</option>
          <option value="0.4" <?php echo '0.4' == $categoryUrlLevel ? 'selected' : ''; ?>>0.4</option>
          <option value="0.3" <?php echo '0.3' == $categoryUrlLevel ? 'selected' : ''; ?>>0.3</option>
          <option value="0.2" <?php echo '0.2' == $categoryUrlLevel ? 'selected' : ''; ?>>0.2</option>
          <option value="0.1" <?php echo '0.1' == $categoryUrlLevel ? 'selected' : ''; ?>>0.1</option>
          <option value="0.0" <?php echo '0.0' == $categoryUrlLevel ? 'selected' : ''; ?>>0.0</option>
        </select>
        &nbsp&nbsp频率：
        <select name="category_url_frequency">
            <?php $categoryUrlFrequency = $config->category_url_frequency; ?>
          <option value="always" <?php echo 'always' == $categoryUrlFrequency ? 'selected' : ''; ?>>always</option>
          <option value="hourly" <?php echo 'hourly' == $categoryUrlFrequency ? 'selected' : ''; ?>>hourly</option>
          <option value="daily" <?php echo 'daily' == $categoryUrlFrequency ? 'selected' : ''; ?>>daily</option>
          <option value="weekly" <?php echo 'weekly' == $categoryUrlFrequency ? 'selected' : ''; ?>>weekly</option>
          <option value="monthly" <?php echo 'monthly' == $categoryUrlFrequency ? 'selected' : ''; ?>>monthly</option>
          <option value="yearly" <?php echo 'yearly' == $categoryUrlFrequency ? 'selected' : ''; ?>>yearly</option>
          <option value="never" <?php echo 'never' == $categoryUrlFrequency ? 'selected' : ''; ?>>never</option>
        </select>
        &nbsp&nbsp数量：
        <input
          type="number"
          min="0"
          name="category_url_number"
          value="<?php echo $config->category_url_number; ?>"
          style="width: 80px">
        (0 表示全部)
      </td>
    </tr>
    <tr>
      <td>标签链接</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="tag_url_status"
          value="<?php echo $config->tag_url_status; ?>">
        &nbsp优先级：
        <select name="tag_url_level">
            <?php $tagUrlLevel = $config->tag_url_level; ?>
          <option value="1.0" <?php echo '1.0' == $tagUrlLevel ? 'selected' : ''; ?>>1.0</option>
          <option value="0.9" <?php echo '0.9' == $tagUrlLevel ? 'selected' : ''; ?>>0.9</option>
          <option value="0.8" <?php echo '0.8' == $tagUrlLevel ? 'selected' : ''; ?>>0.8</option>
          <option value="0.7" <?php echo '0.7' == $tagUrlLevel ? 'selected' : ''; ?>>0.7</option>
          <option value="0.6" <?php echo '0.6' == $tagUrlLevel ? 'selected' : ''; ?>>0.6</option>
          <option value="0.5" <?php echo '0.5' == $tagUrlLevel ? 'selected' : ''; ?>>0.5</option>
          <option value="0.4" <?php echo '0.4' == $tagUrlLevel ? 'selected' : ''; ?>>0.4</option>
          <option value="0.3" <?php echo '0.3' == $tagUrlLevel ? 'selected' : ''; ?>>0.3</option>
          <option value="0.2" <?php echo '0.2' == $tagUrlLevel ? 'selected' : ''; ?>>0.2</option>
          <option value="0.1" <?php echo '0.1' == $tagUrlLevel ? 'selected' : ''; ?>>0.1</option>
          <option value="0.0" <?php echo '0.0' == $tagUrlLevel ? 'selected' : ''; ?>>0.0</option>
        </select>
        &nbsp&nbsp频率：
        <select name="tag_url_frequency">
            <?php $tagUrlFrequency = $config->tag_url_frequency; ?>
          <option value="always" <?php echo 'always' == $tagUrlFrequency ? 'selected' : ''; ?>>always</option>
          <option value="hourly" <?php echo 'hourly' == $tagUrlFrequency ? 'selected' : ''; ?>>hourly</option>
          <option value="daily" <?php echo 'daily' == $tagUrlFrequency ? 'selected' : ''; ?>>daily</option>
          <option value="weekly" <?php echo 'weekly' == $tagUrlFrequency ? 'selected' : ''; ?>>weekly</option>
          <option value="monthly" <?php echo 'monthly' == $tagUrlFrequency ? 'selected' : ''; ?>>monthly</option>
          <option value="yearly" <?php echo 'yearly' == $tagUrlFrequency ? 'selected' : ''; ?>>yearly</option>
          <option value="never" <?php echo 'never' == $tagUrlFrequency ? 'selected' : ''; ?>>never</option>
        </select>
        &nbsp&nbsp数量：
        <input
          type="number"
          min="0"
          name="tag_url_number"
          value="<?php echo $config->tag_url_number; ?>"
          style="width: 80px">
        (0 表示全部)
      </td>
    </tr>
    <tr>
      <td>XML地图</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="xml_status"
          value="<?php echo $config->xml_status; ?>">
        &nbsp地图链接：
        <a href="<?php echo "{$zbp->host}sitemap/sitemap.xml" ?>" target="_blank">
            <?php echo "{$zbp->host}sitemap/sitemap.xml" ?>
        </a>
        （如果失败了，估计是你没有设置伪静态）
      </td>
    </tr>
    <tr>
      <td>TXT地图</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="txt_status"
          value="<?php echo $config->txt_status; ?>">
        &nbsp地图链接：
        <a href="<?php echo "{$zbp->host}sitemap/sitemap.txt" ?>" target="_blank">
            <?php echo "{$zbp->host}sitemap/sitemap.txt" ?>
        </a>
       （如果失败了，估计是你没有设置伪静态）
      </td>
    </tr>
    <tr>
      <td>HTML地图</td>
      <td>
        开关：
        <input
          type="text"
          class="checkbox"
          name="html_status"
          value="<?php echo $config->html_status; ?>">
        &nbsp地图链接：
        <a href="<?php echo "{$zbp->host}sitemap/sitemap.html" ?>" target="_blank">
            <?php echo "{$zbp->host}sitemap/sitemap.html" ?>
        </a>
        （如果失败了，估计是你没有设置伪静态）
      </td>
    </tr>
    <tr>
      <td></td>
      <td style="text-align: center">
        <input type="submit" name="sitemap_save" value="保存设置">
      </td>
    </tr>
  </table>
</form>

