<?php

/**
 * Silence is golden.
 */
