{foreach $articles as $article}
<li><a title="{$article.Title}" href="{$article.Url}">{$article.Title}</a></li>
{/foreach}