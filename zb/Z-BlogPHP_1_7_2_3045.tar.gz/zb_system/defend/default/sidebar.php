{* Template Name:侧栏模板 * Template Type:none *}
{foreach $sidebar as $module}
{template:module}
{/foreach}