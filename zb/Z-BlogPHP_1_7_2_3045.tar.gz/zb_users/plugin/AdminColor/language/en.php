<?php

return array(
    'closemenu'  => 'Collapse',
    'expandmenu' => 'Expand',
);
