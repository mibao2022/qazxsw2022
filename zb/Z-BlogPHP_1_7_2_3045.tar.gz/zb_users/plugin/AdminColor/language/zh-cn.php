<?php

return array(
    'closemenu'  => '收起菜单',
    'expandmenu' => '展开菜单',
);
