﻿
$(document).ready(function () {

    $('#ac_BlodColor').colorpicker();
    $('#ac_NormalColor').colorpicker();
    $('#ac_LightColor').colorpicker();
    $('#ac_HighColor').colorpicker();
    $('#ac_AntiColor').colorpicker();

});
