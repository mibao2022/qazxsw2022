<?php if (!defined('ZBP_PATH')) {
    exit('Access denied');
} ?>
<aside class="left">
  <ul id="leftmenu">
<?php
ResponseAdmin_LeftMenu()
?>
  </ul>
</aside>
