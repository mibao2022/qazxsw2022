<style type="text/css">
  #divMain .SubMenu {
    height: auto;
  }

  i.xnxf-tip {
    background-color: red;
    border-radius: 7px;
    height: 7px;
    padding: 0;
    position: relative;
    right: 8px;
    top: -3px;
    width: 7px;
  }

  #help {
    padding-top: 1em;
  }

  #help a {
    background-color: inherit;
    float: none;
  }

  hr {
    background-color: navajowhite;
    border: none;
    display: block;
    height: 1px;
    margin: 1rem 0;
    visibility: visible;
  }
</style>
<i class="xnxf-tip" style="float: right"></i>
<a href="javascript:;" style="float: right;" onclick="$('#help,#divMain2').slideToggle();$('.xnxf-tip').animate({opacity: 0});SetCookie('xnxf-tip', '2020-06-03', 73)" title="查看/隐藏关于"><span class="m-right">[关于]</span></a>
<div id="help" style="display:none;clear: both">
  <p>
    <img src="https://img.shields.io/badge/-SEO%E6%98%AF%E5%95%A5%E8%81%94%E7%9B%9F-yellowgreen" alt="-SEO是啥联盟"> <a target="_blank" title="Feed-FeedsPub" href="https://feeds.pub/feed/https%3A%2F%2Fwww.wdssmq.com%2Ffeed.php"><img src="https://img.shields.io/badge/Feed-FeedsPub-brightgreen" alt="Feed-FeedsPub"></a> <a target="_blank" title="Feed-Inoreader" href="https://www.innoreader.com/feed/https%3A%2F%2Fwww.wdssmq.com%2Ffeed.php"><img src="https://img.shields.io/badge/Feed-Inoreader-blue" alt="Feed-Inoreader"></a> <a target="_blank" title="Feed-feed.wdssmq.com" href="https://feed.wdssmq.com"><img src="https://img.shields.io/badge/Feed-feed.wdssmq.com-yellow" alt="Feed-feed.wdssmq.com"></a> <a target="_blank" title="mastodon-wdssmq" href="https://acg.mn/invite/DXwRtTMG"><img src="https://img.shields.io/mastodon/follow/59876?domain=https%3A%2F%2Facg.mn%2F" alt="mastodon-wdssmq"></a>
  </p>
  <p>QQ：349467624 <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=349467624&amp;site=qq&amp;menu=yes" title="沉冰浮水的QQ"><img src="https://www.wdssmq.com/zb_users/logos/qq_button.png" alt="QQ" title="QQ"></a></p>
  <p>博客：<a target="_blank" href="https://www.wdssmq.com" title="沉冰浮水">https://www.wdssmq.com</a></p>
  <p>Feed：<a target="_blank" href="https://feed.wdssmq.com" title="Feed">https://feed.wdssmq.com</a></p>
  <p>bilibili：<a target="_blank" href="https://space.bilibili.com/44744006" title="bilibili">https://space.bilibili.com/44744006</a></p>
  <p>知乎：<a target="_blank" href="https://www.zhihu.com/people/wdssmq" title="知乎">https://www.zhihu.com/people/wdssmq</a></p>
  <p>GitHub：<a target="_blank" href="https://github.com/wdssmq" title="GitHub">https://github.com/wdssmq</a></p>
  <p>GreasyFork：<a target="_blank" href="https://greasyfork.org/zh-CN/users/6865-wdssmq" title="GreasyFork">https://greasyfork.org/zh-CN/users/6865-wdssmq</a></p>
  <hr>
  <p>爱发电：<a target="_blank" href="https://afdian.net/@wdssmq" title="爱发电">https://afdian.net/@wdssmq</a></p>
  <p>[AD：<a title="老薛主机" target="_blank" href="https://my.laoxuehost.net/aff.php?aff=294">PHP美国空间</a> 优惠码：15off-xnxf ]</p>
  <p>[AD：<a title="主机云" target="_blank" href="https://my.hostyun.com/page.aspx?c=referral&u=8680">vps-主机云</a>]</p>
  <p>[AD：<a title="Vultr" target="_blank" href="https://www.vultr.com/?ref=7663955">vps-Vultr</a>]</p>
  <hr>
  <p>一款基于QueryList V4的Z-Blog采集插件：<a href="https://github.com/wdssmq/kumo-for-zblog" target="_blank" title="wdssmq/kumo-for-zblog: 一款基于QueryList V4的Z-Blog采集插件">https://github.com/wdssmq/kumo-for-zblog</a></p>
  <p>某理念崩坏的采集插件 - Z-Blog 应用中心</p>
  <p><a href="https://app.zblogcn.com/?id=17788" target="_blank" title="某理念崩坏的采集插件 - Z-Blog 应用中心">https://app.zblogcn.com/?id=17788</a></p>
  <div style="min-height: 59px;"></div>
</div>
<div style="clear: both"></div>
<script type="text/javascript">
  if (GetCookie("xnxf-tip") == '2020-06-03') {
    $('.xnxf-tip').css({
      opacity: 0
    });
  }
</script>