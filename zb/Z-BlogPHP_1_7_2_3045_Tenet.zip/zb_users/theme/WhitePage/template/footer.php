		<div id="divBottom">
			<p id="BlogPowerBy">Powered By {$zblogphphtml}</p>
			<p id="BlogCopyRight">{$copyright}</p>
		</div><div class="clear"></div>
	</div><div class="clear"></div>
	</div><div class="clear"></div>
</div>
{$footer}
</body>
</html>