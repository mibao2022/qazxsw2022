<footer id="base">
  <div class="inner">
    <h4>&copy; {date('Y',time())} <a href="{$host}" class="zit">{$cfg.Logo?$cfg.Logo:$name}</a> {$copyright}</h4>
    <h5>Powered By <a href="//www.zblogcn.com" title="{$zblogphp}" target="_blank">Z-Blog</a> Theme By <a href="//jgpy.cn" target="_blank" title="前端开发·自由设计">吉光片羽</a></h5>
    {$footer}
  </div>
</footer>
</body>
</html>