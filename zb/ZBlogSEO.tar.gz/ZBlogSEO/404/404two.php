<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>404错误！抱歉您要找的页面不存在</title>
<link href="<?php echo $zbp->host ?>zb_users/plugin/ZBlogSEO/404/css/404two.css" rel="stylesheet"/>
</head>

<body>
<div class="container" style=" margin-top:8%;"> 
   <div class="panel margin-big-top">
      <div class="text-center">
         <br>
         <h2 class="padding-top"> <stong>404错误！抱歉您要找的页面不存在</stong> </h2>
         <div class=""> 
            <div class="float-left">
                <img src="<?php echo $zbp->host ?>zb_users/plugin/ZBlogSEO/404/images/ds-1.gif">
                <div class="alert"> 卧槽！页面不见了！ </div>
            </div>
            <div class="float-right">
               <img src="<?php echo $zbp->host ?>zb_users/plugin/ZBlogSEO/404/images/ds-2.png" width="260"> 
            </div>
          </div>
          <div class="padding-big">
               <a href="<?php echo $zbp->host ?>" class="button bg-yellow">返回首页</a>
               <a href="javascript:void(0)" class="button">保证不打死管理员</a>
          </div> 
      </div> 
   </div> 
</div>
</body>
</html>
